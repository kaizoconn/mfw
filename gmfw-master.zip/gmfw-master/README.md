# GMFW

A simple WordPress theme based off MFW and BMFW.

- MFW: http://motherfuckingwebsite.com/
- BMFW: http://bettermotherfuckingwebsite.com/

See it in action at http://www.gaelanlloyd.com.
